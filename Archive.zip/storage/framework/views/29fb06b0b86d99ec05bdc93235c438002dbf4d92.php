<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make(backpack_view('layouts.top_left'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/stefanoverhoeve/Sites/curriculumtool/resources/views/vendor/backpack/base/blank.blade.php ENDPATH**/ ?>