
<?php
    $value = data_get($entry, $column['name']);
    $value = is_string($value) ? $value : ''; // don't try to show arrays/object if the column was autoSet
?>

<span><?php echo $value; ?></span><?php /**PATH /Users/stefanoverhoeve/Sites/curriculumtool/resources/views/vendor/backpack/crud/columns/textarea.blade.php ENDPATH**/ ?>