<!-- This file is used to store topbar (right) items -->



<?php /**PATH /Users/stefanoverhoeve/Sites/curriculumtool/vendor/backpack/crud/src/resources/views/base/inc/topbar_right_content.blade.php ENDPATH**/ ?>