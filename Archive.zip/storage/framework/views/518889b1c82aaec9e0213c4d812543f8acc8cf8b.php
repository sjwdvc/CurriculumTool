
<?php
//$checkValue = data_get($entry, $column['name']);
$function = data_get($entry, $column['relation']);

$checkedIcon = data_get($column, 'icons.checked', 'fa-check-circle');
$uncheckedIcon = data_get($column, 'icons.unchecked', 'fa-circle');

$exportCheckedText = data_get($column, 'labels.checked', trans('backpack::crud.yes'));
$exportUncheckedText = data_get($column, 'labels.unchecked', trans('backpack::crud.no'));

$icon = $function->isEmpty() ? $uncheckedIcon : $checkedIcon;
$text = $function->isEmpty() ? $exportUncheckedText : $exportCheckedText;
?>

<span>
    <i class="fa <?php echo e($icon); ?>"></i>
</span>

<span class="sr-only"><?php echo e($text); ?></span>
<?php /**PATH /Users/stefanoverhoeve/Sites/curriculumtool/resources/views/vendor/backpack/crud/columns/check_for_relation.blade.php ENDPATH**/ ?>