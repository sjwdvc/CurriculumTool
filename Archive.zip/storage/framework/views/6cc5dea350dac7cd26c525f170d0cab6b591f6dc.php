
<?php
    $value = data_get($entry, $column['name']);

    // the value should be an array wether or not attribute casting is used
    if (!is_array($value)) {
        $value = json_decode($value, true);
    }
?>

<span>
    <?php
    if ($value && count($value)) {
        echo implode(', ', $value);
    } else {
        echo '-';
    }
    ?>
</span><?php /**PATH /Users/stefanoverhoeve/Sites/curriculumtool/resources/views/vendor/backpack/crud/columns/array.blade.php ENDPATH**/ ?>