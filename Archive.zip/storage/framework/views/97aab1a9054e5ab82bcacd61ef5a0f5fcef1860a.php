
<span>
    <?php echo $column['function']($entry); ?>

</span><?php /**PATH /Users/stefanoverhoeve/Sites/curriculumtool/resources/views/vendor/backpack/crud/columns/closure.blade.php ENDPATH**/ ?>