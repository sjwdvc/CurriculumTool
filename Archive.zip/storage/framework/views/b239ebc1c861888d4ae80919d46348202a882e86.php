<!-- This file is used to store topbar (right) items -->



<?php /**PATH /Users/stefanoverhoeve/Sites/curriculumtool/resources/views/vendor/backpack/base/inc/topbar_right_content.blade.php ENDPATH**/ ?>